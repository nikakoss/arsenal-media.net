<?php
class WPBakeryShortCode_VC_Twitter extends WPBakeryShortCode {
}